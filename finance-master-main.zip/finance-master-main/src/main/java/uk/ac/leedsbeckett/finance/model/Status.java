package uk.ac.leedsbeckett.finance.model;

public enum Status {
    OUTSTANDING,
    PAID,
    CANCELLED
}
