package uk.ac.leedsbeckett.finance.model;

public enum Type {
    LIBRARY_FINE,
    TUITION_FEES
}
